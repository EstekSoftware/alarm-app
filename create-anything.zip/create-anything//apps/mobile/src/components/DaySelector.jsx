import React from "react";
import { View, Text, TouchableOpacity } from "react-native";

const DAYS = [
  { id: 1, short: "Pzt", full: "Pazartesi" },
  { id: 2, short: "Sal", full: "Salı" },
  { id: 3, short: "Çar", full: "Çarşamba" },
  { id: 4, short: "Per", full: "Perşembe" },
  { id: 5, short: "Cum", full: "Cuma" },
  { id: 6, short: "Cts", full: "Cumartesi" },
  { id: 0, short: "Paz", full: "Pazar" },
];

export default function DaySelector({ selectedDays, onDaysChange }) {
  const toggleDay = (dayId) => {
    if (selectedDays.includes(dayId)) {
      onDaysChange(selectedDays.filter((id) => id !== dayId));
    } else {
      onDaysChange([...selectedDays, dayId]);
    }
  };

  const selectAllDays = () => {
    if (selectedDays.length === 7) {
      onDaysChange([]);
    } else {
      onDaysChange([0, 1, 2, 3, 4, 5, 6]);
    }
  };

  return (
    <View>
      {/* Quick Actions */}
      <View
        style={{
          flexDirection: "row",
          marginBottom: 16,
        }}
      >
        <TouchableOpacity
          onPress={selectAllDays}
          style={{
            backgroundColor: selectedDays.length === 7 ? "#3B82F6" : "#F3F4F6",
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 8,
            marginRight: 8,
          }}
        >
          <Text
            style={{
              fontSize: 12,
              color: selectedDays.length === 7 ? "white" : "#6B7280",
              fontWeight: "600",
            }}
          >
            {selectedDays.length === 7 ? "Tümünü Kaldır" : "Her Gün"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => onDaysChange([1, 2, 3, 4, 5])}
          style={{
            backgroundColor:
              JSON.stringify(selectedDays.sort()) ===
              JSON.stringify([1, 2, 3, 4, 5])
                ? "#3B82F6"
                : "#F3F4F6",
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 8,
          }}
        >
          <Text
            style={{
              fontSize: 12,
              color:
                JSON.stringify(selectedDays.sort()) ===
                JSON.stringify([1, 2, 3, 4, 5])
                  ? "white"
                  : "#6B7280",
              fontWeight: "600",
            }}
          >
            Hafta İçi
          </Text>
        </TouchableOpacity>
      </View>

      {/* Day Grid */}
      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          gap: 8,
        }}
      >
        {DAYS.map((day) => {
          const isSelected = selectedDays.includes(day.id);

          return (
            <TouchableOpacity
              key={day.id}
              onPress={() => toggleDay(day.id)}
              style={{
                flex: 1,
                minWidth: "13%",
                aspectRatio: 1,
                backgroundColor: isSelected ? "#3B82F6" : "#F9FAFB",
                borderWidth: 1,
                borderColor: isSelected ? "#3B82F6" : "#E5E7EB",
                borderRadius: 8,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "600",
                  color: isSelected ? "white" : "#6B7280",
                  textAlign: "center",
                }}
              >
                {day.short}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Selected Days Preview */}
      {selectedDays.length > 0 && (
        <View
          style={{
            marginTop: 16,
            padding: 12,
            backgroundColor: "#F0F9FF",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#BAE6FD",
          }}
        >
          <Text
            style={{
              fontSize: 12,
              color: "#0369A1",
              fontWeight: "500",
            }}
          >
            Seçili günler:{" "}
            {selectedDays
              .sort()
              .map((id) => DAYS.find((d) => d.id === id)?.full)
              .join(", ")}
          </Text>
        </View>
      )}
    </View>
  );
}
