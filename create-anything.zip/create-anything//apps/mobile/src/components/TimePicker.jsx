import React from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";

export default function TimePicker({
  hour,
  minute,
  onHourChange,
  onMinuteChange,
}) {
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const minutes = Array.from({ length: 60 }, (_, i) => i);

  const renderPickerItem = (
    value,
    selectedValue,
    onPress,
    formatValue = (v) => v.toString().padStart(2, "0"),
  ) => (
    <TouchableOpacity
      key={value}
      onPress={() => onPress(value)}
      style={{
        paddingVertical: 12,
        paddingHorizontal: 20,
        borderRadius: 8,
        backgroundColor: selectedValue === value ? "#3B82F6" : "transparent",
        marginVertical: 2,
      }}
    >
      <Text
        style={{
          fontSize: 18,
          textAlign: "center",
          color: selectedValue === value ? "white" : "#1F2937",
          fontWeight: selectedValue === value ? "600" : "normal",
        }}
      >
        {formatValue(value)}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View
      style={{
        flexDirection: "row",
        backgroundColor: "#F9FAFB",
        borderRadius: 12,
        padding: 8,
        height: 200,
      }}
    >
      {/* Hours */}
      <View style={{ flex: 1, marginRight: 8 }}>
        <Text
          style={{
            fontSize: 14,
            fontWeight: "600",
            color: "#6B7280",
            textAlign: "center",
            marginBottom: 8,
          }}
        >
          Saat
        </Text>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 8 }}
        >
          {hours.map((h) => renderPickerItem(h, hour, onHourChange))}
        </ScrollView>
      </View>

      {/* Separator */}
      <View
        style={{
          width: 2,
          backgroundColor: "#E5E7EB",
          alignSelf: "stretch",
          marginVertical: 32,
        }}
      />

      {/* Minutes */}
      <View style={{ flex: 1, marginLeft: 8 }}>
        <Text
          style={{
            fontSize: 14,
            fontWeight: "600",
            color: "#6B7280",
            textAlign: "center",
            marginBottom: 8,
          }}
        >
          Dakika
        </Text>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 8 }}
        >
          {minutes.map((m) => renderPickerItem(m, minute, onMinuteChange))}
        </ScrollView>
      </View>
    </View>
  );
}
