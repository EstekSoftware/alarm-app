import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  Alert,
  AppState,
  BackHandler,
  Dimensions,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { Audio } from "expo-audio";
import { useFocusEffect } from "@react-navigation/native";
import { Gamepad2, Clock } from "lucide-react-native";
import SnakeGame from "@/components/SnakeGame";

export default function AlarmScreen({ alarm, gameDuration, onComplete }) {
  const [timeRemaining, setTimeRemaining] = useState(gameDuration * 60); // seconds
  const [gameStarted, setGameStarted] = useState(false);
  const [sound, setSound] = useState(null);
  const intervalRef = useRef(null);
  const appStateRef = useRef(AppState.currentState);

  // Handle back button - prevent closing during alarm
  useFocusEffect(
    React.useCallback(() => {
      const onBackPress = () => {
        if (timeRemaining > 0) {
          // Prevent back button during game time
          Alert.alert(
            "Alarm Aktif",
            `Oyun bitmeden çıkamazsınız! Kalan süre: ${Math.ceil(timeRemaining / 60)} dakika`,
            [{ text: "Tamam" }],
          );
          return true; // Prevent default behavior
        }
        return false; // Allow default behavior
      };

      BackHandler.addEventListener("hardwareBackPress", onBackPress);
      return () =>
        BackHandler.removeEventListener("hardwareBackPress", onBackPress);
    }, [timeRemaining]),
  );

  // Handle app state changes - prevent backgrounding
  useEffect(() => {
    const handleAppStateChange = (nextAppState) => {
      if (
        timeRemaining > 0 &&
        appStateRef.current.match(/active/) &&
        nextAppState === "background"
      ) {
        // Try to bring app back to foreground
        Alert.alert(
          "Alarm Devam Ediyor",
          "Oyun bitmeden uygulama kapatılamaz!",
          [{ text: "Geri Dön", onPress: () => {} }],
        );
      }
      appStateRef.current = nextAppState;
    };

    const subscription = AppState.addEventListener(
      "change",
      handleAppStateChange,
    );
    return () => subscription?.remove();
  }, [timeRemaining]);

  // Start alarm sound
  useEffect(() => {
    playAlarmSound();
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, []);

  // Countdown timer
  useEffect(() => {
    if (gameStarted && timeRemaining > 0) {
      intervalRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            setGameStarted(false);
            stopAlarmSound();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [gameStarted, timeRemaining]);

  const playAlarmSound = async () => {
    try {
      let soundToPlay;

      if (alarm.music && alarm.music.uri) {
        // Use selected music
        const { sound: customSound } = await Audio.Sound.createAsync(
          { uri: alarm.music.uri },
          { shouldPlay: true, isLooping: true, volume: 1.0 },
        );
        soundToPlay = customSound;
        setSound(soundToPlay);
      } else {
        // No default sound file available, show visual alert
        console.log("Using visual alert instead of sound");
      }
    } catch (error) {
      console.error("Error playing alarm sound:", error);
    }

    // Always show visual alert as fallback
    Alert.alert(
      "ALARM!",
      `${alarm.hour.toString().padStart(2, "0")}:${alarm.minute.toString().padStart(2, "0")} alarmınız çalıyor!`,
      [{ text: "Oyunu Başlat", onPress: startGame }],
    );
  };

  const stopAlarmSound = async () => {
    if (sound) {
      await sound.stopAsync();
      await sound.unloadAsync();
    }
  };

  const startGame = () => {
    setGameStarted(true);
    stopAlarmSound(); // Stop alarm when game starts
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleGameComplete = () => {
    if (timeRemaining <= 0) {
      onComplete();
    }
  };

  if (!gameStarted) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#DC2626",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <StatusBar style="light" />

        <View
          style={{
            backgroundColor: "white",
            borderRadius: 20,
            padding: 40,
            margin: 20,
            alignItems: "center",
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 8,
          }}
        >
          <Text
            style={{
              fontSize: 48,
              fontWeight: "bold",
              color: "#DC2626",
              marginBottom: 16,
            }}
          >
            ALARM!
          </Text>

          <Text
            style={{
              fontSize: 32,
              fontWeight: "bold",
              color: "#1F2937",
              marginBottom: 24,
            }}
          >
            {alarm.hour.toString().padStart(2, "0")}:
            {alarm.minute.toString().padStart(2, "0")}
          </Text>

          <Text
            style={{
              fontSize: 16,
              color: "#6B7280",
              textAlign: "center",
              marginBottom: 32,
              lineHeight: 24,
            }}
          >
            Alarmı kapatmak için {gameDuration} dakika süreyle oyun oynayın!
          </Text>

          <TouchableOpacity
            onPress={startGame}
            style={{
              backgroundColor: "#DC2626",
              paddingHorizontal: 32,
              paddingVertical: 16,
              borderRadius: 12,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Gamepad2 size={24} color="white" />
            <Text
              style={{
                color: "white",
                fontSize: 18,
                fontWeight: "bold",
                marginLeft: 8,
              }}
            >
              Oyunu Başlat
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#1F2937" }}>
      <StatusBar style="light" />

      {/* Game Timer */}
      <View
        style={{
          backgroundColor: "#374151",
          paddingVertical: 16,
          paddingHorizontal: 20,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Clock size={20} color="#9CA3AF" />
          <Text
            style={{
              color: "#9CA3AF",
              fontSize: 14,
              marginLeft: 8,
            }}
          >
            Kalan Süre:
          </Text>
        </View>

        <Text
          style={{
            color: timeRemaining <= 60 ? "#EF4444" : "#10B981",
            fontSize: 18,
            fontWeight: "bold",
          }}
        >
          {formatTime(timeRemaining)}
        </Text>
      </View>

      {/* Snake Game */}
      <View style={{ flex: 1 }}>
        <SnakeGame
          onGameOver={() => {}} // Don't allow game over to exit
          timeRemaining={timeRemaining}
          disabled={timeRemaining <= 0}
        />
      </View>

      {/* Exit Button (only appears when time is up) */}
      {timeRemaining <= 0 && (
        <View
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: "rgba(0,0,0,0.8)",
            padding: 20,
            alignItems: "center",
          }}
        >
          <Text
            style={{
              color: "white",
              fontSize: 18,
              fontWeight: "bold",
              marginBottom: 16,
              textAlign: "center",
            }}
          >
            Tebrikler! Süre doldu, artık çıkabilirsiniz.
          </Text>

          <TouchableOpacity
            onPress={handleGameComplete}
            style={{
              backgroundColor: "#10B981",
              paddingHorizontal: 32,
              paddingVertical: 16,
              borderRadius: 12,
              width: "100%",
              alignItems: "center",
            }}
          >
            <Text
              style={{
                color: "white",
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Oyundan Çık
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}
