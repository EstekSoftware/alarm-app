import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Dimensions,
  PanGestureHandler,
  State,
} from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import {
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
} from "lucide-react-native";

const { width: screenWidth, height: screenHeight } = Dimensions.get("window");
const BOARD_SIZE = 20;
const CELL_SIZE = Math.min(
  (screenWidth - 40) / BOARD_SIZE,
  (screenHeight - 200) / BOARD_SIZE,
);
const GAME_SPEED = 150; // ms

const DIRECTIONS = {
  UP: { x: 0, y: -1 },
  DOWN: { x: 0, y: 1 },
  LEFT: { x: -1, y: 0 },
  RIGHT: { x: 1, y: 0 },
};

export default function SnakeGame({ timeRemaining, disabled }) {
  const [snake, setSnake] = useState([{ x: 10, y: 10 }]);
  const [food, setFood] = useState({ x: 5, y: 5 });
  const [direction, setDirection] = useState(DIRECTIONS.RIGHT);
  const [score, setScore] = useState(0);
  const [gameRunning, setGameRunning] = useState(true);
  const gameLoopRef = useRef(null);

  // Initialize game
  useEffect(() => {
    if (!disabled) {
      generateFood();
      startGameLoop();
    }

    return () => {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
    };
  }, [disabled]);

  // Stop game when time is up
  useEffect(() => {
    if (timeRemaining <= 0) {
      setGameRunning(false);
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
    }
  }, [timeRemaining]);

  const generateFood = () => {
    let newFood;
    do {
      newFood = {
        x: Math.floor(Math.random() * BOARD_SIZE),
        y: Math.floor(Math.random() * BOARD_SIZE),
      };
    } while (
      snake.some(
        (segment) => segment.x === newFood.x && segment.y === newFood.y,
      )
    );

    setFood(newFood);
  };

  const startGameLoop = () => {
    if (gameLoopRef.current) {
      clearInterval(gameLoopRef.current);
    }

    gameLoopRef.current = setInterval(() => {
      moveSnake();
    }, GAME_SPEED);
  };

  const moveSnake = () => {
    setSnake((currentSnake) => {
      const newSnake = [...currentSnake];
      const head = { ...newSnake[0] };

      head.x += direction.x;
      head.y += direction.y;

      // Check wall collision
      if (
        head.x < 0 ||
        head.x >= BOARD_SIZE ||
        head.y < 0 ||
        head.y >= BOARD_SIZE
      ) {
        // Reset snake position instead of game over
        return [
          { x: Math.floor(BOARD_SIZE / 2), y: Math.floor(BOARD_SIZE / 2) },
        ];
      }

      // Check self collision
      if (
        newSnake.some((segment) => segment.x === head.x && segment.y === head.y)
      ) {
        // Reset snake position instead of game over
        return [
          { x: Math.floor(BOARD_SIZE / 2), y: Math.floor(BOARD_SIZE / 2) },
        ];
      }

      newSnake.unshift(head);

      // Check food collision
      if (head.x === food.x && head.y === food.y) {
        setScore((prev) => prev + 10);
        generateFood();
      } else {
        newSnake.pop();
      }

      return newSnake;
    });
  };

  const changeDirection = (newDirection) => {
    // Prevent reverse direction
    if (
      (direction === DIRECTIONS.UP && newDirection === DIRECTIONS.DOWN) ||
      (direction === DIRECTIONS.DOWN && newDirection === DIRECTIONS.UP) ||
      (direction === DIRECTIONS.LEFT && newDirection === DIRECTIONS.RIGHT) ||
      (direction === DIRECTIONS.RIGHT && newDirection === DIRECTIONS.LEFT)
    ) {
      return;
    }
    setDirection(newDirection);
  };

  const resetGame = () => {
    setSnake([
      { x: Math.floor(BOARD_SIZE / 2), y: Math.floor(BOARD_SIZE / 2) },
    ]);
    setDirection(DIRECTIONS.RIGHT);
    setScore(0);
    generateFood();
    if (!disabled) {
      startGameLoop();
    }
  };

  const handleSwipe = (event) => {
    const { translationX, translationY } = event.nativeEvent;

    if (Math.abs(translationX) > Math.abs(translationY)) {
      // Horizontal swipe
      if (translationX > 30) {
        changeDirection(DIRECTIONS.RIGHT);
      } else if (translationX < -30) {
        changeDirection(DIRECTIONS.LEFT);
      }
    } else {
      // Vertical swipe
      if (translationY > 30) {
        changeDirection(DIRECTIONS.DOWN);
      } else if (translationY < -30) {
        changeDirection(DIRECTIONS.UP);
      }
    }
  };

  const renderCell = (x, y) => {
    const isSnake = snake.some((segment) => segment.x === x && segment.y === y);
    const isHead = snake.length > 0 && snake[0].x === x && snake[0].y === y;
    const isFood = food.x === x && food.y === y;

    let backgroundColor = "#374151";
    if (isFood) {
      backgroundColor = "#EF4444";
    } else if (isSnake) {
      backgroundColor = isHead ? "#10B981" : "#22C55E";
    }

    return (
      <View
        key={`${x}-${y}`}
        style={{
          width: CELL_SIZE,
          height: CELL_SIZE,
          backgroundColor,
          borderWidth: 0.5,
          borderColor: "#4B5563",
        }}
      />
    );
  };

  const renderBoard = () => {
    const board = [];
    for (let y = 0; y < BOARD_SIZE; y++) {
      const row = [];
      for (let x = 0; x < BOARD_SIZE; x++) {
        row.push(renderCell(x, y));
      }
      board.push(
        <View key={y} style={{ flexDirection: "row" }}>
          {row}
        </View>,
      );
    }
    return board;
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: "#1F2937",
          padding: 20,
        }}
      >
        {/* Score */}
        <View
          style={{
            marginBottom: 16,
            backgroundColor: "#374151",
            paddingHorizontal: 20,
            paddingVertical: 8,
            borderRadius: 8,
          }}
        >
          <Text
            style={{
              color: "white",
              fontSize: 16,
              fontWeight: "bold",
            }}
          >
            Skor: {score}
          </Text>
        </View>

        {/* Game Board */}
        <PanGestureHandler
          onGestureEvent={handleSwipe}
          onHandlerStateChange={(event) => {
            if (event.nativeEvent.state === State.END) {
              handleSwipe(event);
            }
          }}
          enabled={!disabled && gameRunning}
        >
          <View
            style={{
              backgroundColor: "#374151",
              padding: 4,
              borderRadius: 8,
              marginBottom: 20,
            }}
          >
            {renderBoard()}
          </View>
        </PanGestureHandler>

        {/* Game Instructions */}
        <View
          style={{
            backgroundColor: "#374151",
            padding: 16,
            borderRadius: 8,
            marginBottom: 16,
            width: "100%",
          }}
        >
          <Text
            style={{
              color: "#9CA3AF",
              fontSize: 12,
              textAlign: "center",
              lineHeight: 18,
            }}
          >
            Yılanı hareket ettirmek için ekranı kaydırın{"\n"}🔴 Kırmızı
            noktaları toplayın ve büyüyün!
          </Text>
        </View>

        {/* Control Buttons */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            gap: 16,
          }}
        >
          {/* Direction Buttons */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
            }}
          >
            <TouchableOpacity
              onPress={() => changeDirection(DIRECTIONS.LEFT)}
              disabled={disabled || !gameRunning}
              style={{
                backgroundColor: disabled ? "#4B5563" : "#6B7280",
                padding: 12,
                borderRadius: 8,
              }}
            >
              <ArrowLeft size={20} color="white" />
            </TouchableOpacity>

            <View style={{ alignItems: "center" }}>
              <TouchableOpacity
                onPress={() => changeDirection(DIRECTIONS.UP)}
                disabled={disabled || !gameRunning}
                style={{
                  backgroundColor: disabled ? "#4B5563" : "#6B7280",
                  padding: 12,
                  borderRadius: 8,
                  marginBottom: 4,
                }}
              >
                <ArrowUp size={20} color="white" />
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => changeDirection(DIRECTIONS.DOWN)}
                disabled={disabled || !gameRunning}
                style={{
                  backgroundColor: disabled ? "#4B5563" : "#6B7280",
                  padding: 12,
                  borderRadius: 8,
                }}
              >
                <ArrowDown size={20} color="white" />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              onPress={() => changeDirection(DIRECTIONS.RIGHT)}
              disabled={disabled || !gameRunning}
              style={{
                backgroundColor: disabled ? "#4B5563" : "#6B7280",
                padding: 12,
                borderRadius: 8,
              }}
            >
              <ArrowRight size={20} color="white" />
            </TouchableOpacity>
          </View>

          {/* Reset Button */}
          <TouchableOpacity
            onPress={resetGame}
            disabled={disabled}
            style={{
              backgroundColor: disabled ? "#4B5563" : "#EF4444",
              padding: 12,
              borderRadius: 8,
              marginLeft: 16,
            }}
          >
            <RotateCcw size={20} color="white" />
          </TouchableOpacity>
        </View>

        {disabled && (
          <View
            style={{
              marginTop: 20,
              backgroundColor: "#10B981",
              paddingHorizontal: 20,
              paddingVertical: 12,
              borderRadius: 8,
            }}
          >
            <Text
              style={{
                color: "white",
                fontSize: 16,
                fontWeight: "bold",
                textAlign: "center",
              }}
            >
              Süre Doldu! Artık Çıkabilirsiniz!
            </Text>
          </View>
        )}
      </View>
    </GestureHandlerRootView>
  );
}
