import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  TextInput,
  Alert,
} from "react-native";
import { X, Clock, Gamepad2 } from "lucide-react-native";

export default function SettingsModal({ visible, onClose, settings, onSave }) {
  const [gameDuration, setGameDuration] = useState("5");

  useEffect(() => {
    if (settings) {
      setGameDuration(settings.gameDuration.toString());
    }
  }, [settings]);

  const handleSave = () => {
    const duration = parseInt(gameDuration);

    if (isNaN(duration) || duration < 1 || duration > 30) {
      Alert.alert(
        "Geçersiz Süre",
        "Oyun süresi 1-30 dakika arasında olmalıdır.",
      );
      return;
    }

    onSave({
      gameDuration: duration,
    });
  };

  const presetDurations = [1, 3, 5, 10, 15];

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <View style={{ flex: 1, backgroundColor: "white" }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingHorizontal: 20,
            paddingVertical: 16,
            borderBottomWidth: 1,
            borderBottomColor: "#E5E7EB",
          }}
        >
          <TouchableOpacity onPress={onClose}>
            <X size={24} color="#6B7280" />
          </TouchableOpacity>

          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              color: "#1F2937",
            }}
          >
            Ayarlar
          </Text>

          <TouchableOpacity
            onPress={handleSave}
            style={{
              backgroundColor: "#3B82F6",
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 8,
            }}
          >
            <Text
              style={{
                color: "white",
                fontSize: 14,
                fontWeight: "600",
              }}
            >
              Kaydet
            </Text>
          </TouchableOpacity>
        </View>

        <View style={{ padding: 20 }}>
          {/* Game Duration Setting */}
          <View
            style={{
              backgroundColor: "#F9FAFB",
              borderRadius: 12,
              padding: 16,
              marginBottom: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <Gamepad2 size={20} color="#6B7280" />
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#1F2937",
                  marginLeft: 8,
                }}
              >
                Oyun Süresi
              </Text>
            </View>

            <Text
              style={{
                fontSize: 14,
                color: "#6B7280",
                marginBottom: 16,
                lineHeight: 20,
              }}
            >
              Alarm çaldığında oynayacağınız oyunun süresini belirleyin. Süre
              bitene kadar oyundan çıkamazsınız.
            </Text>

            {/* Preset Duration Buttons */}
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                gap: 8,
                marginBottom: 16,
              }}
            >
              {presetDurations.map((duration) => (
                <TouchableOpacity
                  key={duration}
                  onPress={() => setGameDuration(duration.toString())}
                  style={{
                    backgroundColor:
                      gameDuration === duration.toString()
                        ? "#3B82F6"
                        : "white",
                    borderWidth: 1,
                    borderColor:
                      gameDuration === duration.toString()
                        ? "#3B82F6"
                        : "#E5E7EB",
                    paddingHorizontal: 16,
                    paddingVertical: 8,
                    borderRadius: 8,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      color:
                        gameDuration === duration.toString()
                          ? "white"
                          : "#6B7280",
                      fontWeight: "600",
                    }}
                  >
                    {duration} dk
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Custom Duration Input */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  color: "#6B7280",
                  marginRight: 12,
                }}
              >
                Özel süre:
              </Text>

              <TextInput
                value={gameDuration}
                onChangeText={setGameDuration}
                keyboardType="numeric"
                maxLength={2}
                style={{
                  backgroundColor: "white",
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 8,
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                  fontSize: 14,
                  textAlign: "center",
                  width: 60,
                }}
                placeholder="5"
              />

              <Text
                style={{
                  fontSize: 14,
                  color: "#6B7280",
                  marginLeft: 8,
                }}
              >
                dakika
              </Text>
            </View>

            <View
              style={{
                backgroundColor: "#FEF3C7",
                borderWidth: 1,
                borderColor: "#F59E0B",
                borderRadius: 8,
                padding: 12,
                marginTop: 16,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <Clock size={16} color="#D97706" />
                <Text
                  style={{
                    fontSize: 12,
                    color: "#92400E",
                    marginLeft: 8,
                    flex: 1,
                    lineHeight: 16,
                  }}
                >
                  Uyarı: Bu süre boyunca telefonunuzun hiçbir tuşu çalışmayacak
                  ve uygulamadan çıkamazsınız!
                </Text>
              </View>
            </View>
          </View>

          {/* App Info */}
          <View
            style={{
              backgroundColor: "#F0F9FF",
              borderRadius: 12,
              padding: 16,
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontWeight: "600",
                color: "#1F2937",
                marginBottom: 8,
              }}
            >
              Uygulama Hakkında
            </Text>

            <Text
              style={{
                fontSize: 14,
                color: "#6B7280",
                lineHeight: 20,
              }}
            >
              Bu alarm uygulaması sizi uyandırmak için özel olarak
              tasarlanmıştır. Alarm çaldığında oyun oynayarak tamamen uyanmanızı
              sağlar.
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}
