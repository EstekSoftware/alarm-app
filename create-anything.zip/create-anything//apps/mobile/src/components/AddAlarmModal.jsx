import React, { useState } from "react";
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  ScrollView,
  Alert,
} from "react-native";
import { X, Clock, Music, Calendar } from "lucide-react-native";
import * as DocumentPicker from "expo-document-picker";
import TimePicker from "@/components/TimePicker";
import DaySelector from "@/components/DaySelector";

export default function AddAlarmModal({ visible, onClose, onSave }) {
  const [selectedHour, setSelectedHour] = useState(new Date().getHours());
  const [selectedMinute, setSelectedMinute] = useState(new Date().getMinutes());
  const [selectedDays, setSelectedDays] = useState([]);
  const [selectedMusic, setSelectedMusic] = useState(null);

  const resetForm = () => {
    const now = new Date();
    setSelectedHour(now.getHours());
    setSelectedMinute(now.getMinutes());
    setSelectedDays([]);
    setSelectedMusic(null);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const selectMusic = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "audio/*",
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets && result.assets[0]) {
        const asset = result.assets[0];
        setSelectedMusic({
          uri: asset.uri,
          name: asset.name,
          type: asset.mimeType,
        });
      }
    } catch (error) {
      Alert.alert("Hata", "Müzik seçerken bir hata oluştu.");
    }
  };

  const handleSave = () => {
    if (selectedHour === null || selectedMinute === null) {
      Alert.alert("Hata", "Lütfen saat ve dakikayı seçin.");
      return;
    }

    const newAlarm = {
      hour: selectedHour,
      minute: selectedMinute,
      repeatDays: selectedDays,
      music: selectedMusic,
      musicName: selectedMusic ? selectedMusic.name : "Varsayılan Alarm",
    };

    onSave(newAlarm);
    resetForm();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <View style={{ flex: 1, backgroundColor: "white" }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingHorizontal: 20,
            paddingVertical: 16,
            borderBottomWidth: 1,
            borderBottomColor: "#E5E7EB",
          }}
        >
          <TouchableOpacity onPress={handleClose}>
            <X size={24} color="#6B7280" />
          </TouchableOpacity>

          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              color: "#1F2937",
            }}
          >
            Yeni Alarm
          </Text>

          <TouchableOpacity
            onPress={handleSave}
            style={{
              backgroundColor: "#3B82F6",
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 8,
            }}
          >
            <Text
              style={{
                color: "white",
                fontSize: 14,
                fontWeight: "600",
              }}
            >
              Kaydet
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
          {/* Time Selection */}
          <View
            style={{
              padding: 20,
              borderBottomWidth: 1,
              borderBottomColor: "#F3F4F6",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <Clock size={20} color="#6B7280" />
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#1F2937",
                  marginLeft: 8,
                }}
              >
                Saat Seçin
              </Text>
            </View>

            <TimePicker
              hour={selectedHour}
              minute={selectedMinute}
              onHourChange={setSelectedHour}
              onMinuteChange={setSelectedMinute}
            />
          </View>

          {/* Music Selection */}
          <View
            style={{
              padding: 20,
              borderBottomWidth: 1,
              borderBottomColor: "#F3F4F6",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <Music size={20} color="#6B7280" />
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#1F2937",
                  marginLeft: 8,
                }}
              >
                Alarm Sesi
              </Text>
            </View>

            <TouchableOpacity
              onPress={selectMusic}
              style={{
                backgroundColor: "#F9FAFB",
                borderWidth: 1,
                borderColor: "#E5E7EB",
                borderRadius: 8,
                padding: 16,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  color: selectedMusic ? "#1F2937" : "#6B7280",
                  flex: 1,
                }}
              >
                {selectedMusic ? selectedMusic.name : "Telefondan müzik seç"}
              </Text>
              <Music size={16} color="#6B7280" />
            </TouchableOpacity>

            {selectedMusic && (
              <TouchableOpacity
                onPress={() => setSelectedMusic(null)}
                style={{
                  marginTop: 8,
                  alignSelf: "flex-start",
                }}
              >
                <Text
                  style={{
                    fontSize: 12,
                    color: "#DC2626",
                  }}
                >
                  Müziği Kaldır
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Day Selection */}
          <View
            style={{
              padding: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <Calendar size={20} color="#6B7280" />
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#1F2937",
                  marginLeft: 8,
                }}
              >
                Tekrarlama Günleri
              </Text>
            </View>

            <DaySelector
              selectedDays={selectedDays}
              onDaysChange={setSelectedDays}
            />

            <Text
              style={{
                fontSize: 12,
                color: "#6B7280",
                marginTop: 8,
              }}
            >
              Hiçbir gün seçmezseniz alarm sadece bir kez çalacaktır.
            </Text>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}
