import React from "react";
import { View, Text, TouchableOpacity, Switch } from "react-native";
import { Trash2, Music } from "lucide-react-native";

const DAYS = ["Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cts"];

export default function AlarmItem({ alarm, onToggle, onDelete }) {
  const formatTime = (hour, minute) => {
    return `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`;
  };

  const getRepeatDaysText = () => {
    if (alarm.repeatDays.length === 0) {
      return "Bir kez";
    }
    if (alarm.repeatDays.length === 7) {
      return "Her gün";
    }
    return alarm.repeatDays
      .sort()
      .map((day) => DAYS[day])
      .join(", ");
  };

  return (
    <View
      style={{
        backgroundColor: "white",
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: alarm.enabled ? "#E5E7EB" : "#F3F4F6",
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 4,
        elevation: 2,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 8,
        }}
      >
        <Text
          style={{
            fontSize: 32,
            fontWeight: "bold",
            color: alarm.enabled ? "#1F2937" : "#9CA3AF",
          }}
        >
          {formatTime(alarm.hour, alarm.minute)}
        </Text>

        <Switch
          value={alarm.enabled}
          onValueChange={() => onToggle(alarm.id)}
          trackColor={{ false: "#F3F4F6", true: "#3B82F6" }}
          thumbColor={alarm.enabled ? "white" : "#9CA3AF"}
        />
      </View>

      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 14,
              color: alarm.enabled ? "#6B7280" : "#9CA3AF",
              marginBottom: 4,
            }}
          >
            {getRepeatDaysText()}
          </Text>

          {alarm.musicName && (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Music size={14} color={alarm.enabled ? "#6B7280" : "#9CA3AF"} />
              <Text
                style={{
                  fontSize: 12,
                  color: alarm.enabled ? "#6B7280" : "#9CA3AF",
                  marginLeft: 4,
                }}
              >
                {alarm.musicName}
              </Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          onPress={() => onDelete(alarm.id)}
          style={{
            padding: 8,
            backgroundColor: "#FEE2E2",
            borderRadius: 6,
            marginLeft: 12,
          }}
        >
          <Trash2 size={18} color="#DC2626" />
        </TouchableOpacity>
      </View>
    </View>
  );
}
