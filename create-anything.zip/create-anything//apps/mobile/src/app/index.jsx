import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, TouchableOpacity, Alert } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Plus, Clock, Settings } from "lucide-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import AlarmItem from "@/components/AlarmItem";
import AddAlarmModal from "@/components/AddAlarmModal";
import SettingsModal from "@/components/SettingsModal";
import AlarmScreen from "@/components/AlarmScreen";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [alarms, setAlarms] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [activeAlarm, setActiveAlarm] = useState(null);
  const [gameSettings, setGameSettings] = useState({
    gameDuration: 5, // dakika
  });

  useEffect(() => {
    loadAlarms();
    loadSettings();
    checkAlarms();
  }, []);

  const loadAlarms = async () => {
    try {
      const stored = await AsyncStorage.getItem("alarms");
      if (stored) {
        setAlarms(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Alarmları yüklerken hata:", error);
    }
  };

  const loadSettings = async () => {
    try {
      const stored = await AsyncStorage.getItem("gameSettings");
      if (stored) {
        setGameSettings(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Ayarları yüklerken hata:", error);
    }
  };

  const saveAlarms = async (newAlarms) => {
    try {
      await AsyncStorage.setItem("alarms", JSON.stringify(newAlarms));
      setAlarms(newAlarms);
    } catch (error) {
      console.error("Alarmları kaydederken hata:", error);
    }
  };

  const saveSettings = async (newSettings) => {
    try {
      await AsyncStorage.setItem("gameSettings", JSON.stringify(newSettings));
      setGameSettings(newSettings);
    } catch (error) {
      console.error("Ayarları kaydederken hata:", error);
    }
  };

  const checkAlarms = () => {
    const interval = setInterval(() => {
      const now = new Date();
      const currentTime = now.getHours() * 60 + now.getMinutes();
      const currentDay = now.getDay();

      alarms.forEach((alarm) => {
        if (!alarm.enabled) return;

        const alarmTime = alarm.hour * 60 + alarm.minute;

        // Alarmın çalması gereken zaman mı?
        if (Math.abs(currentTime - alarmTime) < 1) {
          // Tekrarlama günlerini kontrol et
          if (
            alarm.repeatDays.length === 0 ||
            alarm.repeatDays.includes(currentDay)
          ) {
            triggerAlarm(alarm);
          }
        }
      });
    }, 30000); // 30 saniyede bir kontrol et

    return () => clearInterval(interval);
  };

  const triggerAlarm = (alarm) => {
    setActiveAlarm(alarm);
  };

  const addAlarm = (newAlarm) => {
    const updatedAlarms = [
      ...alarms,
      { ...newAlarm, id: Date.now(), enabled: true },
    ];
    saveAlarms(updatedAlarms);
    setShowAddModal(false);
  };

  const toggleAlarm = (id) => {
    const updatedAlarms = alarms.map((alarm) =>
      alarm.id === id ? { ...alarm, enabled: !alarm.enabled } : alarm,
    );
    saveAlarms(updatedAlarms);
  };

  const deleteAlarm = (id) => {
    Alert.alert("Alarmı Sil", "Bu alarmı silmek istediğinize emin misiniz?", [
      { text: "İptal", style: "cancel" },
      {
        text: "Sil",
        style: "destructive",
        onPress: () => {
          const updatedAlarms = alarms.filter((alarm) => alarm.id !== id);
          saveAlarms(updatedAlarms);
        },
      },
    ]);
  };

  const updateGameSettings = (newSettings) => {
    saveSettings(newSettings);
    setShowSettingsModal(false);
  };

  if (activeAlarm) {
    return (
      <AlarmScreen
        alarm={activeAlarm}
        gameDuration={gameSettings.gameDuration}
        onComplete={() => setActiveAlarm(null)}
      />
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "white", paddingTop: insets.top }}>
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          paddingHorizontal: 20,
          paddingVertical: 16,
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <Text
          style={{
            fontSize: 24,
            fontWeight: "bold",
            color: "#1F2937",
          }}
        >
          Alarmlarım
        </Text>

        <TouchableOpacity
          onPress={() => setShowSettingsModal(true)}
          style={{
            padding: 8,
            backgroundColor: "#F3F4F6",
            borderRadius: 8,
          }}
        >
          <Settings size={24} color="#6B7280" />
        </TouchableOpacity>
      </View>

      {/* Alarms List */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
        showsVerticalScrollIndicator={false}
      >
        {alarms.length === 0 ? (
          <View
            style={{
              flex: 1,
              justifyContent: "center",
              alignItems: "center",
              paddingVertical: 100,
            }}
          >
            <Clock size={64} color="#9CA3AF" />
            <Text
              style={{
                fontSize: 18,
                color: "#9CA3AF",
                marginTop: 16,
                textAlign: "center",
              }}
            >
              Henüz alarm kurulmamış.{"\n"}İlk alarmınızı ekleyin!
            </Text>
          </View>
        ) : (
          <View style={{ paddingHorizontal: 16, paddingTop: 16 }}>
            {alarms.map((alarm) => (
              <AlarmItem
                key={alarm.id}
                alarm={alarm}
                onToggle={toggleAlarm}
                onDelete={deleteAlarm}
              />
            ))}
          </View>
        )}
      </ScrollView>

      {/* Add Alarm Button */}
      <TouchableOpacity
        onPress={() => setShowAddModal(true)}
        style={{
          position: "absolute",
          bottom: insets.bottom + 20,
          right: 20,
          backgroundColor: "#3B82F6",
          width: 60,
          height: 60,
          borderRadius: 30,
          justifyContent: "center",
          alignItems: "center",
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.25,
          shadowRadius: 8,
          elevation: 5,
        }}
      >
        <Plus size={28} color="white" />
      </TouchableOpacity>

      <AddAlarmModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSave={addAlarm}
      />

      <SettingsModal
        visible={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        settings={gameSettings}
        onSave={updateGameSettings}
      />
    </View>
  );
}
